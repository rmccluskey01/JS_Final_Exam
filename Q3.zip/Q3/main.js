//JavaScript Document

let button = document.querySelector('button');

requestURL = 'https://jessicagilfillan.github.io/Final_Exam_Prep/Q3/cats.json';
request = new XMLHttpRequest();
request.open('GET', requestURL);
request.responseType = 'json';
request.send();

request.onload = function request() {
  let catsJSON = request.response;
  console.log(catsJSON);
  products(catsJSON);
};

button.addEventListener('click', function btnOnClick(e)){
  let p = document.createElement('p');
  let body = document.querySelector('body');
  let cats = request();
  p.innerHTML = "This is " + cats.name + ", this is a " + cats.species + ", their favourite food is "
  + cats.favFoods + ", and he is " + cats.age + " old.";
  body.appendChild(p);
}

async function fetchCats(){
  const getRequest = await request.onLoad;
  const getCats = await btnOnClick();
  return getCats;
}
