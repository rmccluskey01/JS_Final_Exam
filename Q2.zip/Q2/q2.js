// JavaScript Document

//This class named 'Person' is created to get and set the values of 'name', 'age',
//'gender', and 'inerests'.
class Person {
//this is the constructor method that sets up the string parameters for the 'Person' class.
  constructor(name, age, gender, interests) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.interests = interests;
  }
//the greeting function creates a message in the browser's console that gathers the
//name of the created 'Person' in the class.
  greeting() {
    console.log(`Hi! I'm ${this.name}`);
  };
//Another message that uses the 'name' parameter to be included in the message.
  bye() {
    console.log(`${this.name} has left the building. Bye for now!`);
  };
}

//These are 2 instance variables to create a default 'Person'. that can be used in the
//greeting() and bye() methods.
let parth = new Person('Parth', 20, 'male', ['JavaScript', 'Java', 'PHP']);
let harmanpreet = new Person('Harmanpreet', 22, 'male', ['JavaScript', 'C#', 'Relational DataBase']);

//Another class is created called 'Teacher' that uses values from the 'Person' class.
class Teacher extends Person {
//the constructor method uses the values from the 'Person' class as a super,
//because those values were used in an existing class.
//The 'Teacher' class also has 2 more parameters exclusively for the 'Teacher' class.
  constructor(name, age, gender, interests, subject, grade) {
    super(name, age, gender, interests);
    // subject and grade are specific to Teacher
    this.subject = subject;
    this.grade = grade;
  }
}
//Instance variable that I created for the 'Teacher' class.
let reilly = new Teacher('Reilly', 18, 'male', ['Java', 'Python', 'C#', 'JavaScript'], 'JavaScript', 85);
