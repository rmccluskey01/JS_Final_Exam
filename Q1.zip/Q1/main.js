// JavaScript Document

let main = document.querySelectorAll('main');
let submitButton = document.querySelector('input[type="submit"]');
//'input' variable did not exist so the 'personName' variable wouldn't be functional
let input = document.querySelector('input[type="text"]');
//typo for 'document.querySelector' not 'documant.*'.
let body = document.querySelector('body');
//event listener name is 'click', not 'clickityclick'.
submitButton.addEventListener('click', function(e) {
  let personName = input.value;
  let para = document.createElement('p');
  para.innerHTML = '<h3>Hey there ' + personName + '! Thanks for stopping by!</h3>';
//the <p> element variable is called 'para' not 'paragraph'.
  main.appendChild(para);
//class id is called 'container' instead of 'meow'.
  body.setAttribute('class', 'container');
  console.log('=^..^=');
});
